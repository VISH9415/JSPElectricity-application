package com.cg.ebill.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.service.EBillService;
import com.cg.ebill.service.EBillServiceImpl;

@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   EBillService service;
   public EBillController() {       
		super();
		service= new EBillServiceImpl();
  }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BillDTO bill= new BillDTO();
		String action= request.getParameter("action");
		//System.out.println(action);
		RequestDispatcher rd=null;
		switch(action){
		
		case "1" :
				String conNo= request.getParameter("consumerNo");
				String lreading= request.getParameter("lastReading");
				String creading= request.getParameter("currentReading");
				double fixed= 100;
				double units= Integer.parseInt(creading)-Integer.parseInt(lreading);
				double amount = units*1.15+ fixed;
					
				bill.setConsumerNo(conNo);
				bill.setCurrentReading(Double.parseDouble(creading));
				bill.setUnitsConsumed(units);
				bill.setNetAmount(amount);
				System.out.println("bill details"+ bill);
			try {
				int billid= service.insertBillDetails(bill);
				System.out.println("Bill id : "+ billid);
				ConsumerDTO consumer= service.selectConsumerDetails(conNo);
				request.setAttribute("Bill", bill);
				request.setAttribute("consumer", consumer);
				rd= request.getRequestDispatcher("PrintBill.jsp");
				rd.forward(request, response);
			
			} catch (BillException e) {
				
				request.setAttribute("Error", e.getMessage());
				rd= request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
				}
			break;
		case "2":
			try {
				ArrayList<ConsumerDTO> list=service.listConsumers();
				request.setAttribute("consumerList", list);
				rd= request.getRequestDispatcher("ShowConsumer_list.jsp");
				rd.forward(request, response);
			} catch (BillException e) {
				request.setAttribute("Error", e.getMessage());
				rd= request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
			}
			break;
		case "3" :
			 	rd= request.getRequestDispatcher("Search_Consumer.jsp");
			 	rd.forward(request, response);
			break;
		case "4":
			conNo= request.getParameter("conNo");
			try {
					ConsumerDTO consumer= service.selectConsumerDetails(conNo);
					request.setAttribute("consumer", consumer);
					rd= request.getRequestDispatcher("ShowConsumer.jsp");
					 rd.forward(request, response);
			} catch (BillException e) {
				request.setAttribute("Error", e.getMessage());
				rd= request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
				}
			break;
		case "6":
			String cno= request.getParameter("consumerNo");
			try {
				ArrayList<BillDTO> list= service.selectBillDetails(cno);
				request.setAttribute("billList", list);
				rd=request.getRequestDispatcher("ShowBills.jsp");
				rd.forward(request, response);
			} catch (BillException e) {
				request.setAttribute("Error", e.getMessage());
				rd= request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
			}
			break;
		case "7" : 
				response.sendRedirect("Bill_Info.html");
				break;
		}
		
		
	
	}

}
