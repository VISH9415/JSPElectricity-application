package com.cg.ebill.service;

import java.util.ArrayList;

import com.cg.ebill.dao.EBillDAO;
import com.cg.ebill.dao.EBillDaoImpl;
import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.exception.BillException;

public class EBillServiceImpl implements EBillService{
	EBillDAO dao;
	public EBillServiceImpl() {
		dao= new EBillDaoImpl();
	}	
	@Override
	public int insertBillDetails(BillDTO bill) throws BillException {
		return dao.insertBillDetails(bill);
	}
	@Override
	public ConsumerDTO selectConsumerDetails(String conNo) throws BillException {
		return dao.selectConsumerDetails(conNo);
	}
	@Override
	public ArrayList<ConsumerDTO> listConsumers() throws BillException {
		return dao.listConsumers();
	}
	@Override
	public ArrayList<BillDTO> selectBillDetails(String conNo)
			throws BillException {
		return dao.selectBillDetails(conNo);
	}
}
